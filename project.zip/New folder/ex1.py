from bitcoin.core.script import *
from utils import *
import hashlib
from config import (my_private_key, my_public_key, my_address,
                    faucet_address)
from bitcoin.core.script import OP_DUP, OP_HASH160, OP_EQUALVERIFY, OP_CHECKSIG


def P2PKH_scriptPubKey(address):
 
    return [OP_DUP,OP_HASH160,address,OP_EQUALVERIFY,OP_CHECKSIG]
 
	 
def P2PKH_scriptSig(txin, txout, txin_scriptPubKey):

    signature = create_OP_CHECKSIG_signature(txin, txout, txin_scriptPubKey,
                                             my_private_key)
											 
    
    return [signature,my_public_key]



def send_from_P2PKH_transaction(amount_to_send, txid_to_spend, utxo_index,
                                txout_scriptPubKey):
    txout = create_txout(amount_to_send, txout_scriptPubKey)
    txin_scriptPubKey = P2PKH_scriptPubKey(my_address) 
    txin = create_txin(txid_to_spend, utxo_index)
    txin_scriptSig = P2PKH_scriptSig(txin, txout, txin_scriptPubKey)
    new_tx = create_signed_transaction(txin, txout, txin_scriptPubKey,
                                       txin_scriptSig)

    return broadcast_transaction(new_tx)
   


if __name__ == '__main__':

    amount_to_send = 0.18076185
    txid_to_spend = (
        'cc1f868bb24bac091d6c6dc3a429ba48bfa44e700612d031246e8a17a4c0cea5')
    utxo_index = 0
	
    txout_scriptPubKey = P2PKH_scriptPubKey(faucet_address)
    response = send_from_P2PKH_transaction(
        amount_to_send, txid_to_spend, utxo_index, txout_scriptPubKey)
    print(response.status_code, response.reason)
    print(response.text)