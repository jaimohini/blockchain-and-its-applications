from sys import exit
from bitcoin.core.script import *

from utils import *
from config import my_private_key, my_public_key, my_address, faucet_address
from ex1 import send_from_P2PKH_transaction
from bitcoin.core.script import OP_2DUP,OP_ADD,OP_EQUALVERIFY,OP_SUB,OP_EQUAL


ex2a_txout_scriptPubKey = [OP_2DUP , OP_ADD , 10 , OP_EQUALVERIFY  , OP_SUB, 2 ,OP_EQUAL]


if __name__ == '__main__':
    
    amount_to_send = 0.13919809
    txid_to_spend = (
        '5badccfb670d4c218a9099093bc598333ad35402b92e2d957964e526ce4c8af0')
    utxo_index = 1

    response = send_from_P2PKH_transaction(
        amount_to_send, txid_to_spend, utxo_index,
        ex2a_txout_scriptPubKey)
    print(response.status_code, response.reason)
    print(response.text)
