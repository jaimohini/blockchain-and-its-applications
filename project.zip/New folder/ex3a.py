from sys import exit
from bitcoin.core.script import *
from bitcoin.wallet import P2PKHBitcoinAddress,CBitcoinSecret
from utils import *
from config import my_private_key, my_public_key, my_address, faucet_address
from ex1 import send_from_P2PKH_transaction
from bitcoin.core.script import OP_DUP, OP_HASH160, OP_EQUALVERIFY, OP_CHECKSIG ,OP_CHECKMULTISIG


cust1_private_key = CBitcoinSecret(
    'cTWptVFBaMhbdQtnNkrFPMqQk2Xe17uk62zTq64qCNo8DDcP5qJ4')
cust1_public_key = cust1_private_key.pub
cust2_private_key = CBitcoinSecret(
    'cVRHMe4MNbmvqEnTDWAA8voFA2gox6p3V3CuZXikj76K2ANQbWn3')
cust2_public_key = cust2_private_key.pub
cust3_private_key = CBitcoinSecret(
    'cT6u2RbNAUewEfnQSssSs5gj9z2KyYGAPNXjM7eKCEViwfKM2Ngr')
cust3_public_key = cust3_private_key.pub


ex3a_txout_scriptPubKey=[OP_DUP,OP_HASH160,my_address,OP_EQUALVERIFY,OP_CHECKSIGVERIFY,1,cust1_public_key,cust2_public_key,cust3_public_key,3,OP_CHECKMULTISIG ]

 
if __name__ == '__main__':
   
    amount_to_send = 0.0744474
    txid_to_spend = (
        '18b4c6cdf8f9f369c2c7c4469e57d532171bf95662b9017bff5e71b11af47d91')
    utxo_index = 1

    response = send_from_P2PKH_transaction(
        amount_to_send, txid_to_spend, utxo_index,
        ex3a_txout_scriptPubKey)
    print(response.status_code, response.reason)
    print(response.text)
